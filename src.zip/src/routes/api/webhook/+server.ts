// src/routes/api/webhook/+server.ts
import type { RequestHandler } from './$types';
import { json } from '@sveltejs/kit';
import { processMessage, type BotContext } from '$lib/chatbot/engine';
import { logConversationEvent } from '$lib/chatbot/store';

/**
 * Ejemplo de webhook genérico.
 * Aquí deberías adaptar el body según lo que envía WhatsApp / tu frontend.
 */
export const POST: RequestHandler = async ({ request }) => {
  const body = await request.json();

  // Adapta esto a tu payload real de WhatsApp o de tu chat web
  const incomingText: string = body?.text ?? '';
  const conversationId: string =
    body?.conversationId ?? body?.from ?? 'unknown-conversation';
  const channel = (body?.channel ?? 'whatsapp') as BotContext['channel'];

  if (!incomingText || conversationId === 'unknown-conversation') {
    return json(
      { ok: false, error: 'Parámetros insuficientes' },
      { status: 400 }
    );
  }

  const ctx: BotContext = {
    conversationId,
    text: incomingText,
    channel,
    previousState: body?.previousState ?? null,
    userId: body?.userId ?? null,
    metadata: {
      raw: body
    }
  };

  // 1. Procesar mensaje con el motor del bot
  const botResponse = await processMessage(ctx);

  // 2. Loguear en Firestore (conversación + mensajes)
  await logConversationEvent(ctx, botResponse, body);

  // 3. Aquí podrías llamar a la API de WhatsApp para enviar la respuesta real
  //    Por ahora solo devolvemos el JSON.
  return json({
    ok: true,
    reply: botResponse.reply,
    intent: botResponse.intent,
    nextState: botResponse.nextState,
    needsHuman: botResponse.needsHuman
  });
};
