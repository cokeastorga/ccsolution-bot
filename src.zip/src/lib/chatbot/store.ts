// src/lib/chatbot/store.ts
import {
  collection,
  doc,
  serverTimestamp,
  setDoc,
  addDoc,
  updateDoc,
  getDoc
} from 'firebase/firestore';
import { db } from '$lib/firebase';
import type { BotContext, BotResponse } from '$lib/chatbot/engine';

export type ConversationStatus = 'open' | 'pending' | 'closed';

export interface ConversationDoc {
  channel: 'whatsapp' | 'web';
  userId?: string | null;
  status: ConversationStatus;
  lastMessageAt: any;
  lastMessageText: string;
  lastIntentId?: string | null;
  needsHuman?: boolean;
  createdAt: any;
  updatedAt: any;
}

/**
 * Asegura que exista un documento de conversación.
 * Si no existe, lo crea. Si existe, solo actualiza timestamps básicos.
 */
export async function ensureConversation(ctx: BotContext, response?: BotResponse) {
  const ref = doc(db, 'conversations', ctx.conversationId);
  const snap = await getDoc(ref);

  const base: Partial<ConversationDoc> = {
    channel: ctx.channel,
    userId: ctx.userId ?? null,
    status: 'open',
    lastMessageAt: serverTimestamp(),
    lastMessageText: ctx.text,
    lastIntentId: response?.intent.id ?? null,
    needsHuman: response?.needsHuman ?? false,
    updatedAt: serverTimestamp()
  };

  if (!snap.exists()) {
    await setDoc(ref, {
      ...base,
      createdAt: serverTimestamp()
    } as ConversationDoc);
  } else {
    await updateDoc(ref, base);
  }

  return ref;
}

/**
 * Registra un mensaje individual dentro de una conversación.
 */
export async function logMessage(
  ctx: BotContext,
  options: {
    direction: 'in' | 'out';
    text: string;
    response?: BotResponse;
    rawPayload?: unknown;
  }
) {
  const convRef = doc(db, 'conversations', ctx.conversationId);

  const messagesCol = collection(convRef, 'messages');

  const stateBefore = ctx.previousState ?? null;
  const stateAfter = options.response?.nextState ?? stateBefore;

  await addDoc(messagesCol, {
    direction: options.direction,
    text: options.text,
    intentId: options.response?.intent.id ?? null,
    confidence: options.response?.intent.confidence ?? null,
    stateBefore,
    stateAfter,
    channel: ctx.channel,
    createdAt: serverTimestamp(),
    raw: options.rawPayload ?? null
  });
}

/**
 * Helper de alto nivel: dado un mensaje entrante y la respuesta del bot,
 * actualiza la conversación y guarda ambos mensajes.
 */
export async function logConversationEvent(
  ctx: BotContext,
  response: BotResponse,
  rawPayload?: unknown
) {
  // 1. Aseguramos conversación
  await ensureConversation(ctx, response);

  // 2. Guardamos mensaje entrante (usuario)
  await logMessage(ctx, {
    direction: 'in',
    text: ctx.text,
    rawPayload
  });

  // 3. Guardamos mensaje saliente (bot)
  await logMessage(ctx, {
    direction: 'out',
    text: response.reply,
    response,
    rawPayload: null
  });

  // 4. Actualizamos algunos flags en la conversación (ej: needsHuman, estado)
  const convRef = doc(db, 'conversations', ctx.conversationId);

  const status: ConversationStatus =
    response.nextState === 'ended' ? 'closed' : 'open';

  await updateDoc(convRef, {
    status,
    lastMessageAt: serverTimestamp(),
    lastMessageText: response.reply,
    lastIntentId: response.intent.id,
    needsHuman: response.needsHuman ?? false,
    updatedAt: serverTimestamp()
  });
}
