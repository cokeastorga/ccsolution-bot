<script lang="ts">
  export let variant: 'default' | 'success' | 'warning' | 'info' = 'default';

  const base =
    'inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium';

  const variants = {
    default: 'bg-slate-100 text-slate-700',
    success: 'bg-emerald-50 text-emerald-700',
    warning: 'bg-amber-50 text-amber-700',
    info: 'bg-sky-50 text-sky-700'
  };

  $: classes = `${base} ${variants[variant]}`;
</script>

<span class={classes}>
  <slot />
</span>
