<script lang="ts">
  export let status: 'open' | 'pending' | 'closed' | string = 'open';

  const map = {
    open: {
      label: 'Abierta',
      classes: 'bg-emerald-50 text-emerald-700'
    },
    pending: {
      label: 'Pendiente',
      classes: 'bg-amber-50 text-amber-700'
    },
    closed: {
      label: 'Cerrada',
      classes: 'bg-slate-100 text-slate-600'
    }
  } as const;

  const config =
    (status && map[status as keyof typeof map]) ??
    map.open;
</script>

<span
  class={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium ${config.classes}`}
>
  <span class="mr-1 text-[9px]">●</span>
  {config.label}
</span>
